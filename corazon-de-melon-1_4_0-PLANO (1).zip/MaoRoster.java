package com.corazondemelon.ai;

import com.corazondemelon.entity.MaoEntity;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * La «lista de Maos» de un jugador: el primero que domestica es el Mao REPRESENTANTE (se llama siempre «Mao»,
 * te sigue a todas partes y no se puede renombrar); los demás se pueden renombrar para no confundirlos.
 * Se guarda en los datos del jugador (la lista de UUID) y en cada Mao (su nombre).
 */
public final class MaoRoster {
    public static final String KEY_LIST = "corazondemelon_maos";
    public static final String KEY_REP = "corazondemelon_mao_rep";

    /** Mensaje dirigido a uno o a todos los Maos. */
    public record Target(List<MaoEntity> maos, String text, boolean all) {}

    private static final Pattern ALL = Pattern.compile("^@?(?:maos|todos(?:\\s+los\\s+maos)?)\\s*[\\s,:;!¡]+(.+)$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern NUMBERED = Pattern.compile("^@?mao\\s*(\\d{1,2}|dos|tres|cuatro|cinco|seis)\\b\\s*[,:;!¡]*\\s*(.*)$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Forma simple del comando: «/mao 2 vuelve», «/mao 3 ven». */
    private static final Pattern CMD_NUM = Pattern.compile("^(\\d{1,2}|uno|dos|tres|cuatro|cinco|seis)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern GENERIC = Pattern.compile("^@?mao[\\s,:;!¡]+(.+)$", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private MaoRoster() {}

    private static ListTag list(ServerPlayer p) {
        return p.getPersistentData().getList(KEY_LIST, Tag.TAG_STRING);
    }

    public static String nameOf(MaoEntity m) {
        return m.getCustomName() != null ? m.getCustomName().getString() : "Mao";
    }

    /** Apunta un Mao recién domesticado (o descubierto) en la lista del jugador. */
    public static void register(ServerPlayer p, MaoEntity m) {
        ListTag l = list(p);
        String id = m.getUUID().toString();
        boolean known = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.getString(i).equals(id)) {
                known = true;
                break;
            }
        }
        if (!known) {
            l.add(StringTag.valueOf(id));
            p.getPersistentData().put(KEY_LIST, l);
        }
        String rep = p.getPersistentData().getString(KEY_REP);
        if (rep.isEmpty()) {
            rep = id;
            p.getPersistentData().putString(KEY_REP, id);
        }
        if (rep.equals(id)) {
            m.makeRepresentative();
        } else {
            if (m.getCustomName() == null) m.setCustomName(Component.literal("Mao " + Math.max(2, l.size())));
            m.setCustomNameVisible(true);
        }
    }

    public static void forget(ServerPlayer p, MaoEntity m) {
        ListTag l = list(p);
        String id = m.getUUID().toString();
        ListTag out = new ListTag();
        for (int i = 0; i < l.size(); i++) if (!l.getString(i).equals(id)) out.add(StringTag.valueOf(l.getString(i)));
        p.getPersistentData().put(KEY_LIST, out);
        if (id.equals(p.getPersistentData().getString(KEY_REP))) p.getPersistentData().remove(KEY_REP);
    }

    /** Todos los Maos del jugador que estén cargados ahora mismo (en cualquier dimensión). */
    public static List<MaoEntity> owned(ServerPlayer p, boolean scanNearby) {
        LinkedHashMap<UUID, MaoEntity> out = new LinkedHashMap<>();
        ListTag l = list(p);
        for (int i = 0; i < l.size(); i++) {
            UUID id;
            try {
                id = UUID.fromString(l.getString(i));
            } catch (IllegalArgumentException e) {
                continue;
            }
            for (ServerLevel lv : p.server.getAllLevels()) {
                Entity e = lv.getEntity(id);
                if (e instanceof MaoEntity m && m.isAlive() && m.isOwnedByUuid(p)) {
                    out.put(id, m);
                    break;
                }
            }
        }
        if (scanNearby) {
            for (MaoEntity m : p.level().getEntitiesOfClass(MaoEntity.class, p.getBoundingBox().inflate(64),
                    x -> x.isAlive() && x.isOwnedByUuid(p))) {
                if (!out.containsKey(m.getUUID())) {
                    register(p, m);
                    out.put(m.getUUID(), m);
                }
            }
            if (out.isEmpty() && l.isEmpty()) {
                MaoEntity legacy = MaoEntity.scanOwned(p);
                if (legacy != null) {
                    register(p, legacy);
                    out.put(legacy.getUUID(), legacy);
                }
            }
        }
        return new ArrayList<>(out.values());
    }

    public static List<MaoEntity> owned(ServerPlayer p) {
        return owned(p, true);
    }

    public static List<MaoEntity> followers(ServerPlayer p) {
        List<MaoEntity> out = new ArrayList<>();
        for (MaoEntity m : owned(p, false)) if (m.isFollowing()) out.add(m);
        return out;
    }

    /** El Mao representante si está cargado; si no, el más cercano. */
    public static MaoEntity primary(ServerPlayer p) {
        List<MaoEntity> all = owned(p);
        if (all.isEmpty()) return null;
        for (MaoEntity m : all) if (m.isRepresentative()) return m;
        return all.stream().min(Comparator.comparingDouble(m -> m.level() == p.level() ? m.distanceToSqr(p) : Double.MAX_VALUE)).orElse(null);
    }

    /** Busca un Mao del jugador por su nombre (ignora mayúsculas y tildes). */
    public static MaoEntity byName(ServerPlayer p, String name) {
        String key = MaoPlaces.norm(name);
        if (key.isEmpty()) return null;
        MaoEntity partial = null;
        for (MaoEntity m : owned(p)) {
            String n = MaoPlaces.norm(nameOf(m));
            if (n.equals(key)) return m;
            if (partial == null && (n.contains(key) || key.contains(n)) && !n.equals("mao")) partial = m;
        }
        return partial;
    }

    /** Si el mensaje empieza por el nombre de alguno de tus Maos («Mao 2, ven», «Luna: quédate», «Todos, venid»). */
    public static Target resolve(ServerPlayer p, String raw) {
        if (raw == null || raw.isBlank()) return null;
        String text = raw.trim();
        List<MaoEntity> maos = owned(p);
        if (maos.isEmpty()) return null;

        Matcher all = ALL.matcher(text);
        if (all.matches()) return new Target(maos, all.group(1).trim(), true);

        // «Mao 2» = el segundo Mao de tu lista (aunque le hayas cambiado el nombre)
        Matcher nm = NUMBERED.matcher(text);
        if (nm.matches() && !nm.group(2).isBlank()) {
            String w = nm.group(1).toLowerCase();
            int n = w.matches("\\d+") ? Integer.parseInt(w)
                    : switch (w) { case "dos" -> 2; case "tres" -> 3; case "cuatro" -> 4; case "cinco" -> 5; default -> 6; };
            ListTag l = list(p);
            if (n >= 1 && n <= l.size()) {
                for (MaoEntity m : maos) {
                    if (m.getUUID().toString().equals(l.getString(n - 1))) return new Target(List.of(m), nm.group(2).trim(), false);
                }
                MaoActions.say(p, "No encuentro a Mao " + n + ": debe de estar lejos o en una zona descargada. Acércate a él y vuelve a intentarlo.");
            } else {
                MaoActions.say(p, "Solo tengo " + l.size() + " Mao(s) en tu lista. Escribe «Mao, mis maos» para ver cuáles son.");
            }
            return null;
        }
        List<MaoEntity> byLen = new ArrayList<>(maos);
        byLen.sort((a, b) -> nameOf(b).length() - nameOf(a).length());
        for (MaoEntity m : byLen) {
            String name = nameOf(m);
            String q = Pattern.quote(name);
            Pattern pt;
            if (MaoPlaces.norm(name).startsWith("mao")) {
                pt = Pattern.compile("^@?" + q + "(?:\\s*[,:;!¡]+\\s*|\\s+)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            } else {
                pt = Pattern.compile("^(?:@" + q + "(?:\\s*[,:;!¡]+\\s*|\\s+)|" + q + "\\s*[,:;]+\\s*)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            }
            Matcher mt = pt.matcher(text);
            if (mt.find()) {
                String rest = text.substring(mt.end()).trim();
                if (!rest.isEmpty()) return new Target(List.of(m), rest, false);
            }
        }
        Matcher g = GENERIC.matcher(text);
        if (g.matches()) {
            MaoEntity near = primary(p);
            if (near != null) return new Target(List.of(near), g.group(1).trim(), false);
        }
        return null;
    }

    /** Para /mao <mensaje>: igual que resolve, pero si no empieza por un nombre se lo dices al representante. */
    public static Target resolveOrDefault(ServerPlayer p, String raw) {
        String text = raw.trim();
        List<MaoEntity> maos = owned(p);
        if (maos.isEmpty()) return null;

        // /mao 2 vuelve · /mao 3 ven  (el número es su posición en tu lista; el 1 es el representante)
        Matcher cm = CMD_NUM.matcher(text);
        if (cm.matches()) {
            String w = cm.group(1).toLowerCase();
            int n = w.matches("\\d+") ? Integer.parseInt(w)
                    : switch (w) { case "uno" -> 1; case "dos" -> 2; case "tres" -> 3; case "cuatro" -> 4; case "cinco" -> 5; default -> 6; };
            ListTag l = list(p);
            if (n < 1 || n > l.size()) {
                MaoActions.say(p, "Solo tengo " + l.size() + " Mao(s) en tu lista. Escribe «/mao mis maos» para ver cuáles son.");
                return new Target(List.of(), "", false);
            }
            for (MaoEntity m : maos) {
                if (m.getUUID().toString().equals(l.getString(n - 1))) return new Target(List.of(m), cm.group(2).trim(), false);
            }
            MaoActions.say(p, "No encuentro al Mao " + n + ": debe de estar lejos o en una zona descargada. Acércate a él y vuelve a intentarlo.");
            return new Target(List.of(), "", false);
        }

        Target t = resolve(p, text);
        if (t != null) return t;
        if (NUMBERED.matcher(text).matches()) return new Target(List.of(), "", false);   // «Mao 2 ...» ya avisó de que no lo encuentra

        // /mao Luna ven
        List<MaoEntity> byLen = new ArrayList<>(maos);
        byLen.sort((x, y) -> nameOf(y).length() - nameOf(x).length());
        for (MaoEntity m : byLen) {
            Matcher nmm = Pattern.compile("^" + Pattern.quote(nameOf(m)) + "\\s+(.+)$", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE).matcher(text);
            if (nmm.matches()) return new Target(List.of(m), nmm.group(1).trim(), false);
        }
        MaoEntity m = primary(p);
        return m == null ? null : new Target(List.of(m), text, false);
    }

    /** Cambia quién es el representante. */
    public static void setRepresentative(ServerPlayer p, MaoEntity mao) {
        List<MaoEntity> all = owned(p);
        ListTag l = list(p);
        for (MaoEntity o : all) {
            if (o != mao && o.isRepresentative()) {
                o.clearRepresentative();
                int idx = 0;
                for (int i = 0; i < l.size(); i++) if (l.getString(i).equals(o.getUUID().toString())) idx = i + 1;
                o.setCustomName(Component.literal("Mao " + Math.max(2, idx)));
                o.setCustomNameVisible(true);
            }
        }
        p.getPersistentData().putString(KEY_REP, mao.getUUID().toString());
        mao.clearRepresentative();
        mao.makeRepresentative();
    }

    /** Se llama al domesticar un Mao. */
    public static void onTamed(MaoEntity mao, ServerPlayer player) {
        // primero apunta los Maos que ya tuvieras, para que el más antiguo sea el representante
        for (MaoEntity other : player.level().getEntitiesOfClass(MaoEntity.class, player.getBoundingBox().inflate(64),
                x -> x != mao && x.isAlive() && x.isOwnedByUuid(player))) {
            register(player, other);
        }
        register(player, mao);
        if (!mao.isRepresentative()) {
            player.displayClientMessage(Component.literal("Este es " + nameOf(mao)
                    + ". Puedes cambiarle el nombre: «" + nameOf(mao) + ", llámate Luna». El primer Mao es tu representante y siempre va contigo."), false);
        } else {
            player.displayClientMessage(Component.literal("Este es tu Mao representante: te seguirá a todas partes, siempre."), false);
        }
    }
}
