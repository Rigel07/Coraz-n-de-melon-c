package com.corazondemelon.entity;

import com.corazondemelon.MelonConfig;
import com.corazondemelon.ai.MaoActions;
import com.corazondemelon.ai.MaoMods;
import com.corazondemelon.innocence.Innocence;
import com.corazondemelon.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import com.corazondemelon.ai.MaoRoster;
import com.corazondemelon.ai.MaoWork;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.List;

/**
 * Mao: un pequeño ángel volador.
 *  - Salvaje: se acerca a jugadores con Inocencia 6+ y les regala objetos. Huye de jugadores "Brutos" (nv 1-3).
 *  - Domesticable (nv 3+) con zanahorias doradas. Una vez domesticado es INMORTAL, te sigue (u obedece "quédate"),
 *    te defiende, te cura y es tu asistente por el chat (ver MaoBrain / MaoActions).
 */
public class MaoEntity extends TamableAnimal {
    public static final int GIFT_MIN_LEVEL = 6;
    public static final int TAME_MIN_LEVEL = 3;

    private record GiftEntry(Item item, int minLevel, int weight, int max) {}

    private static final List<GiftEntry> GIFTS = List.of(
            new GiftEntry(Items.APPLE, 6, 30, 3),
            new GiftEntry(Items.BREAD, 6, 25, 2),
            new GiftEntry(Items.COOKIE, 6, 25, 4),
            new GiftEntry(Items.GOLDEN_CARROT, 6, 20, 2),
            new GiftEntry(Items.EXPERIENCE_BOTTLE, 7, 10, 2),
            new GiftEntry(Items.EMERALD, 8, 6, 2),
            new GiftEntry(Items.GOLDEN_APPLE, 9, 4, 1),
            new GiftEntry(Items.DIAMOND, 10, 2, 1)
    );

    private long nextGift = 0L;
    private long nextHeal = 0L;
    private long nextAnnounce = 0L;
    private long nextSocial = 0L;
    private long nextHugXp = 0L;

    /** Amigo (de otro mod o mascota del mismo dueño) al que Mao va a abrazar. */
    private LivingEntity hugTarget;
    private long hugUntil = 0L;

    /** Estructuras ya comentadas por este Mao (para no repetirse). */
    public final Set<String> announced = new HashSet<>();

    // ------------------------------------------------------------------ 1.4.0: color, inventario, trabajos y niveles

    private static final EntityDataAccessor<Integer> DATA_COLOR =
            SynchedEntityData.defineId(MaoEntity.class, EntityDataSerializers.INT);
    private static final UUID ATK_MOD = UUID.fromString("7c1d8e52-3f0b-4a6d-9a41-5e2b6f9c0a37");
    public static final String[] COLOR_KEYS = {"original", "rosa", "verde", "azul", "violeta"};

    /** Qué está haciendo un Mao suelto: seguirte (normal), proteger una zona, picar o explorar buscando material. */
    public enum Mode { FOLLOW, GUARD, MINE, EXPLORE }

    /** Inventario infinito propio. */
    public final MaoInventory inventory = new MaoInventory();
    private boolean representative;
    private Mode mode = Mode.FOLLOW;
    private BlockPos anchor;
    private String anchorDim = "";
    private int zoneRadius = 16;
    private String jobTarget = "";
    private int jobAmount;
    private int jobGot;
    private int lastLevel = TAME_MIN_LEVEL;

    /** Estado temporal del trabajo (no se guarda). */
    public BlockPos jobPos;
    public long nextWork;
    public long nextScan;
    public int noTargetScans;
    public int stuck;
    public final Set<BlockPos> blacklist = new HashSet<>();

    public MaoEntity(EntityType<? extends MaoEntity> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
        this.setNoGravity(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    public boolean isOwnedByUuid(Player player) {
        UUID id = this.getOwnerUUID();
        return this.isTame() && id != null && id.equals(player.getUUID());
    }

    /** El Mao representante del jugador (o el más cercano si el representante no está cargado). */
    @Nullable
    public static MaoEntity findOwnedMao(ServerPlayer player) {
        return MaoRoster.primary(player);
    }

    /** Búsqueda antigua: el Mao domesticado más cercano; si no hay ninguno cerca, cualquiera suyo cargado en cualquier dimensión. */
    @Nullable
    public static MaoEntity scanOwned(ServerPlayer player) {
        List<MaoEntity> list = player.level().getEntitiesOfClass(MaoEntity.class,
                player.getBoundingBox().inflate(64), m -> m.isAlive() && m.isOwnedByUuid(player));
        MaoEntity near = list.stream().min(Comparator.comparingDouble(m -> m.distanceToSqr(player))).orElse(null);
        if (near != null) return near;
        for (ServerLevel lv : player.server.getAllLevels()) {
            for (Entity e : lv.getAllEntities()) {
                if (e instanceof MaoEntity m && m.isAlive() && m.isOwnedByUuid(player)) return m;
            }
        }
        return null;
    }

    /**
     * Mueve a Mao a otro punto, también entre dimensiones (copiando sus datos).
     * @return el Mao resultante (en otra dimensión es una copia con los mismos datos y dueño).
     */
    public MaoEntity warpTo(ServerLevel target, double x, double y, double z) {
        this.getNavigation().stop();
        if (target == this.level()) {
            this.moveTo(x, y, z, this.getYRot(), this.getXRot());
            this.setDeltaMovement(Vec3.ZERO);
            return this;
        }
        CompoundTag tag = new CompoundTag();
        this.saveWithoutId(tag);
        MaoEntity copy = ModEntities.MAO.get().create(target);
        if (copy == null) return this;
        copy.load(tag);
        copy.moveTo(x, y, z, this.getYRot(), this.getXRot());
        copy.setDeltaMovement(Vec3.ZERO);
        target.addFreshEntity(copy);
        this.discard();
        return copy;
    }

    /** Si cae al vacío lo devuelve junto a su dueño (o al spawn del mundo). */
    private void rescue() {
        if (!(this.level() instanceof ServerLevel sl)) return;
        UUID id = this.getOwnerUUID();
        ServerPlayer owner = id == null ? null : sl.getServer().getPlayerList().getPlayer(id);
        if (owner != null) {
            this.warpTo(owner.serverLevel(), owner.getX(), owner.getY() + 1.0, owner.getZ());
        } else {
            BlockPos sp = sl.getSharedSpawnPos();
            this.warpTo(sl, sp.getX() + 0.5, sp.getY() + 1.0, sp.getZ() + 0.5);
        }
    }

    // ------------------------------------------------------------------ datos nuevos (color, nombre, modos)

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_COLOR, 0);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MaoColor", getColor());
        tag.putBoolean("MaoRep", representative);
        tag.putString("MaoMode", mode.name());
        tag.put("MaoInv", inventory.save());
        tag.putInt("MaoZoneR", zoneRadius);
        tag.putString("MaoJob", jobTarget);
        tag.putInt("MaoJobAmt", jobAmount);
        tag.putInt("MaoJobGot", jobGot);
        tag.putInt("MaoLvl", lastLevel);
        if (anchor != null) {
            tag.putBoolean("MaoHasAnchor", true);
            tag.putInt("MaoAX", anchor.getX());
            tag.putInt("MaoAY", anchor.getY());
            tag.putInt("MaoAZ", anchor.getZ());
        }
        tag.putString("MaoADim", anchorDim);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setColor(tag.getInt("MaoColor"));
        representative = tag.getBoolean("MaoRep");
        try {
            mode = Mode.valueOf(tag.getString("MaoMode"));
        } catch (IllegalArgumentException e) {
            mode = Mode.FOLLOW;
        }
        inventory.load(tag.getList("MaoInv", Tag.TAG_COMPOUND));
        zoneRadius = tag.contains("MaoZoneR") ? tag.getInt("MaoZoneR") : 16;
        jobTarget = tag.getString("MaoJob");
        jobAmount = tag.getInt("MaoJobAmt");
        jobGot = tag.getInt("MaoJobGot");
        if (tag.contains("MaoLvl")) lastLevel = tag.getInt("MaoLvl");
        anchor = tag.getBoolean("MaoHasAnchor") ? new BlockPos(tag.getInt("MaoAX"), tag.getInt("MaoAY"), tag.getInt("MaoAZ")) : null;
        anchorDim = tag.getString("MaoADim");
        if (mode != Mode.FOLLOW && (anchor == null || representative)) mode = Mode.FOLLOW;
    }

    public int getColor() {
        return this.entityData.get(DATA_COLOR);
    }

    public void setColor(int color) {
        this.entityData.set(DATA_COLOR, Mth.clamp(color, 0, COLOR_KEYS.length - 1));
    }

    public boolean isRepresentative() {
        return representative;
    }

    /** El representante siempre se llama «Mao», te sigue a todas partes y no se puede sentar ni mandar a trabajar. */
    public void makeRepresentative() {
        representative = true;
        mode = Mode.FOLLOW;
        super.setCustomName(Component.literal("Mao"));
        this.setCustomNameVisible(true);
        super.setOrderedToSit(false);
        this.setInSittingPose(false);
    }

    public void clearRepresentative() {
        representative = false;
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        if (representative) return;      // el representante siempre se llama «Mao»
        super.setCustomName(name);
    }

    @Override
    public void setOrderedToSit(boolean sit) {
        if (sit && representative) return;
        super.setOrderedToSit(sit);
    }

    /** ¿Va detrás de su dueño (y se teletransporta con él)? */
    public boolean isFollowing() {
        if (!this.isTame()) return false;
        if (representative) return true;
        return !this.isOrderedToSit() && mode == Mode.FOLLOW;
    }

    public Mode getMode() {
        return mode;
    }

    @Nullable
    public BlockPos getAnchor() {
        return anchor;
    }

    public String getAnchorDim() {
        return anchorDim;
    }

    public int getZoneRadius() {
        return zoneRadius;
    }

    public String getJobTarget() {
        return jobTarget;
    }

    public int getJobAmount() {
        return jobAmount;
    }

    public int getJobGot() {
        return jobGot;
    }

    public void addJobGot(int n) {
        jobGot += n;
    }

    public int getLastLevel() {
        return lastLevel;
    }

    public void returnToFollow() {
        mode = Mode.FOLLOW;
        jobPos = null;
        blacklist.clear();
        noTargetScans = 0;
        stuck = 0;
        this.getNavigation().stop();
    }

    public void startGuard(BlockPos where, String dim, int radius) {
        mode = Mode.GUARD;
        anchor = where;
        anchorDim = dim;
        zoneRadius = Mth.clamp(radius, 4, 48);
        jobPos = null;
        this.setOrderedToSit(false);
        this.setInSittingPose(false);
    }

    public void startJob(Mode m, String target, int amount) {
        mode = m;
        jobTarget = target;
        jobAmount = amount;
        jobGot = 0;
        jobPos = null;
        blacklist.clear();
        noTargetScans = 0;
        stuck = 0;
        nextWork = 0L;
        nextScan = 0L;
        anchor = this.blockPosition();
        anchorDim = this.level().dimension().location().toString();
        this.setOrderedToSit(false);
        this.setInSittingPose(false);
    }

    /** El dueño si está conectado (en cualquier dimensión). */
    @Nullable
    public ServerPlayer ownerPlayer() {
        UUID id = this.getOwnerUUID();
        if (id == null || !(this.level() instanceof ServerLevel sl)) return null;
        return sl.getServer().getPlayerList().getPlayer(id);
    }

    // ------------------------------------------------------------------ poder según la Inocencia del dueño

    /** Daño extra según el nivel de Inocencia (nv 1-3: 0 · nv 10: +14). */
    public static double damageBonus(int level) {
        return switch (Mth.clamp(level, 1, 10)) {
            case 1, 2, 3 -> 0.0D;
            case 4 -> 1.0D;
            case 5 -> 2.0D;
            case 6 -> 3.0D;
            case 7 -> 5.0D;
            case 8 -> 7.0D;
            case 9 -> 10.0D;
            default -> 14.0D;
        };
    }

    private void applyLevelPower() {
        ServerPlayer owner = ownerPlayer();
        if (owner != null) lastLevel = Innocence.getLevel(owner);
        double bonus = MelonConfig.LEVEL_POWERS.get() ? damageBonus(lastLevel) : 0.0D;
        AttributeInstance atk = this.getAttribute(Attributes.ATTACK_DAMAGE);
        if (atk == null) return;
        AttributeModifier cur = atk.getModifier(ATK_MOD);
        if (cur != null && cur.getAmount() == bonus) return;
        if (cur != null) atk.removeModifier(ATK_MOD);
        if (bonus > 0.0D) {
            atk.addTransientModifier(new AttributeModifier(ATK_MOD, "corazondemelon_innocence_damage", bonus, AttributeModifier.Operation.ADDITION));
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean ok = super.doHurtTarget(target);
        if (ok && MelonConfig.LEVEL_POWERS.get() && target instanceof LivingEntity victim && !this.level().isClientSide) {
            int lvl = lastLevel;
            if (lvl >= 5) victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
            if (lvl >= 7) {
                victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                victim.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
            }
            if (lvl >= 9 && victim.getMobType() == MobType.UNDEAD) victim.hurt(this.damageSources().magic(), 6.0F);
            if (lvl >= 10) {
                ServerPlayer owner = ownerPlayer();
                if (owner != null && owner.getHealth() < owner.getMaxHealth()) owner.heal(1.0F);
            }
        }
        return ok;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide && this.isTame()) {
            ServerPlayer owner = ownerPlayer();
            if (owner != null) MaoRoster.forget(owner, this);
        }
        super.die(source);
    }

    /** ¿Debe atacar a este monstruo según lo que esté haciendo? */
    private boolean shouldFight(LivingEntity e) {
        return switch (mode) {
            case FOLLOW -> true;
            case GUARD -> {
                if (anchor == null) yield true;
                double r = zoneRadius + 6.0D;
                yield e.distanceToSqr(anchor.getX() + 0.5D, anchor.getY() + 0.5D, anchor.getZ() + 0.5D) < r * r;
            }
            default -> this.distanceToSqr(e) < 64.0D;
        };
    }

    /** Meta de trabajo: proteger una zona, picar o explorar (la lógica está en MaoWork). */
    private class WorkGoal extends Goal {
        WorkGoal() {
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return MaoEntity.this.isTame() && !MaoEntity.this.isOrderedToSit() && !MaoEntity.this.representative
                    && MaoEntity.this.mode != Mode.FOLLOW && MaoEntity.this.getTarget() == null;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void tick() {
            MaoWork.tickJob(MaoEntity.this);
        }

        @Override
        public void stop() {
            MaoEntity.this.getNavigation().stop();
        }
    }

    // ------------------------------------------------------------------ IA / movimiento

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
        nav.setCanOpenDoors(false);
        nav.setCanFloat(true);
        nav.setCanPassDoors(true);
        return nav;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new PanicGoal(this, 1.4D) {
            @Override
            public boolean canUse() {
                return !MaoEntity.this.isTame() && super.canUse();
            }
        });
        this.goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Player.class, 10.0F, 1.2D, 1.5D,
                e -> !this.isTame() && e instanceof Player pl && Innocence.getLevel(pl) < TAME_MIN_LEVEL));
        this.goalSelector.addGoal(3, new HugFriendGoal());
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.0D, 5.0F, 2.0F, true) {
            @Override
            public boolean canUse() {
                return MaoEntity.this.mode == Mode.FOLLOW && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return MaoEntity.this.mode == Mode.FOLLOW && super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(5, new WorkGoal());
        this.goalSelector.addGoal(5, new ApproachInnocentGoal(this));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this) {
            @Override
            public boolean canUse() {
                return MaoEntity.this.isTame() && super.canUse();
            }
        });
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false,
                e -> this.isTame() && !this.isOrderedToSit() && !(e instanceof Creeper) && this.shouldFight(e)));
        this.targetSelector.addGoal(5, new DefendFriendsGoal());
    }

    // ------------------------------------------------------------------ convivencia con otros mods

    /** Mao nunca ataca a sus amigos (criaturas amigas de otros mods, mascotas de su dueño y otros Maos). */
    @Override
    public boolean canAttack(LivingEntity target) {
        if (MaoMods.isFriend(this, target)) return false;
        return super.canAttack(target);
    }

    /** Pide a Mao que vaya a abrazar a un amigo (dura como mucho 20 s). */
    public void startHug(LivingEntity friend) {
        this.hugTarget = friend;
        this.hugUntil = this.level().getGameTime() + 400L;
    }

    private void doHug(LivingEntity friend) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        sl.sendParticles(ParticleTypes.HEART, friend.getX(), friend.getY() + friend.getBbHeight() + 0.2, friend.getZ(), 6, 0.3, 0.2, 0.3, 0.0);
        sl.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 1.0, this.getZ(), 3, 0.3, 0.2, 0.3, 0.0);
        sl.playSound(null, this.blockPosition(), SoundEvents.ALLAY_ITEM_GIVEN, SoundSource.NEUTRAL, 1.0F, 1.6F);
        if (friend.getHealth() < friend.getMaxHealth()) friend.heal(4.0F);
        if (this.getOwner() instanceof ServerPlayer owner) {
            owner.displayClientMessage(Component.translatable("message.corazondemelon.mao_hug", friend.getDisplayName()), true);
            long now = sl.getGameTime();
            if (now >= nextHugXp) {                       // ser cariñoso sube la Inocencia, pero solo cada ~3 minutos
                Innocence.addXp(owner, 0.5F);
                nextHugXp = now + 3600L;
            }
        }
    }

    private class HugFriendGoal extends Goal {
        HugFriendGoal() {
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return MaoEntity.this.isTame() && !MaoEntity.this.isOrderedToSit() && hugTarget != null && hugTarget.isAlive()
                    && MaoEntity.this.level().getGameTime() < hugUntil && MaoEntity.this.getTarget() == null;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void tick() {
            MaoEntity.this.getLookControl().setLookAt(hugTarget, 30.0F, 30.0F);
            if (MaoEntity.this.distanceToSqr(hugTarget) > 4.0D) {
                if (MaoEntity.this.tickCount % 10 == 0) MaoEntity.this.getNavigation().moveTo(hugTarget, 1.2D);
            } else {
                doHug(hugTarget);
                hugTarget = null;
            }
        }

        @Override
        public void stop() {
            MaoEntity.this.getNavigation().stop();
        }
    }

    /** Si algo ataca a un amigo de Mao, Mao va a defenderlo. */
    private class DefendFriendsGoal extends Goal {
        private LivingEntity attacker;

        DefendFriendsGoal() {
            this.setFlags(EnumSet.of(Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            if (!MaoEntity.this.isTame() || MaoEntity.this.isOrderedToSit()) return false;
            if (!MelonConfig.MOD_INTERACTIONS.get() || !MelonConfig.PROTECT_FRIENDS.get()) return false;
            if (MaoEntity.this.tickCount % 10 != 0) return false;
            for (Mob m : MaoEntity.this.level().getEntitiesOfClass(Mob.class, MaoEntity.this.getBoundingBox().inflate(16.0D),
                    e -> e.isAlive() && e != MaoEntity.this)) {
                LivingEntity victim = m.getTarget();
                if (victim == null || victim == m || m instanceof Creeper) continue;
                if (m instanceof TamableAnimal ta && ta.isTame()) continue;
                if (!MaoMods.isFriend(MaoEntity.this, victim) || MaoMods.isFriend(MaoEntity.this, m)) continue;
                if (!MaoEntity.this.canAttack(m)) continue;
                attacker = m;
                return true;
            }
            return false;
        }

        @Override
        public boolean canContinueToUse() {
            return attacker != null && attacker.isAlive() && MaoEntity.this.getTarget() == attacker && !MaoEntity.this.isOrderedToSit();
        }

        @Override
        public void start() {
            MaoEntity.this.setTarget(attacker);
        }

        @Override
        public void stop() {
            if (MaoEntity.this.getTarget() == attacker) MaoEntity.this.setTarget(null);
            attacker = null;
        }
    }

    /** Un Mao salvaje se acerca a quien tenga suficiente Inocencia. */
    private static class ApproachInnocentGoal extends Goal {
        private final MaoEntity mao;
        private Player target;
        private int recalc;

        ApproachInnocentGoal(MaoEntity mao) {
            this.mao = mao;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (mao.isTame()) return false;
            Player p = mao.level().getNearestPlayer(mao, 16.0D);
            if (p == null || p.isSpectator() || Innocence.getLevel(p) < TAME_MIN_LEVEL || mao.distanceToSqr(p) < 9.0D) return false;
            target = p;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && target.isAlive() && !mao.isTame() && mao.distanceToSqr(target) > 6.0D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void tick() {
            if (--recalc <= 0) {
                recalc = 10;
                mao.getNavigation().moveTo(target, 1.0D);
            }
            mao.getLookControl().setLookAt(target, 30.0F, 30.0F);
        }

        @Override
        public void stop() {
            target = null;
            mao.getNavigation().stop();
        }
    }

    // ------------------------------------------------------------------ comportamiento

    @Override
    public void aiStep() {
        super.aiStep();
        if (!this.level().isClientSide && this.isAlive() && this.tickCount % 20 == 0) {
            serverTick();
        }
    }

    private void serverTick() {
        long now = this.level().getGameTime();
        ServerLevel level = (ServerLevel) this.level();

        if (!this.isTame()) {
            Player near = level.getNearestPlayer(this, 5.0D);
            if (near instanceof ServerPlayer sp && !sp.isSpectator() && now >= nextGift) {
                int lvl = Innocence.getLevel(sp);
                if (lvl >= GIFT_MIN_LEVEL) {
                    giveGift(level, sp, lvl);
                    nextGift = now + 4800 + this.random.nextInt(4800);
                }
            }
        } else {
            if (this.getHealth() < this.getMaxHealth()) this.heal(1.0F);
            applyLevelPower();
            if (representative) {
                if (this.isOrderedToSit()) {
                    super.setOrderedToSit(false);
                    this.setInSittingPose(false);
                }
                if (mode != Mode.FOLLOW) returnToFollow();
            }
            if (MelonConfig.MOD_INTERACTIONS.get() && MelonConfig.MOD_HUGS.get() && hugTarget == null
                    && !this.isOrderedToSit() && now >= nextSocial) {
                nextSocial = now + 1200L + this.random.nextInt(1200);        // se pasa a saludar cada 1-2 minutos
                LivingEntity friend = MaoMods.nearestFriend(this, 8.0D);
                if (friend != null) startHug(friend);
            }
            if (this.getOwner() instanceof ServerPlayer owner) {
                if (now >= nextHeal && owner.getHealth() < owner.getMaxHealth() * 0.5F && this.distanceToSqr(owner) < 256.0D) {
                    owner.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
                    level.sendParticles(ParticleTypes.HEART, owner.getX(), owner.getY() + 1.8, owner.getZ(), 6, 0.4, 0.3, 0.4, 0.0);
                    level.playSound(null, this.blockPosition(), SoundEvents.ALLAY_ITEM_GIVEN, SoundSource.NEUTRAL, 1.0F, 1.4F);
                    nextHeal = now + 600;
                }
                if (MelonConfig.ANNOUNCE_STRUCTURES.get() && this.tickCount % 200 == 0 && now >= nextAnnounce
                        && this.level() == owner.level() && this.distanceToSqr(owner) < 1600.0D) {
                    if (MaoActions.announceNearby(owner, this)) nextAnnounce = now + 1200;
                }
            }
        }
    }

    private void giveGift(ServerLevel level, ServerPlayer player, int lvl) {
        List<GiftEntry> pool = new ArrayList<>();
        int total = 0;
        for (GiftEntry g : GIFTS) {
            if (lvl >= g.minLevel()) {
                pool.add(g);
                total += g.weight();
            }
        }
        if (pool.isEmpty()) return;
        int roll = this.random.nextInt(total);
        GiftEntry chosen = pool.get(0);
        for (GiftEntry g : pool) {
            roll -= g.weight();
            if (roll < 0) {
                chosen = g;
                break;
            }
        }
        ItemStack stack = new ItemStack(chosen.item(), 1 + this.random.nextInt(chosen.max()));
        // Con criaturas amigas cerca (de otros mods), a veces regala flores (de Minecraft o de cualquier mod).
        if (MelonConfig.MOD_INTERACTIONS.get() && this.random.nextInt(100) < 35 && MaoMods.nearestFriend(this, 16.0D) != null) {
            Item flower = MaoMods.randomFlower(this.random);
            if (flower != null) stack = new ItemStack(flower, 1 + this.random.nextInt(3));
        }
        ItemEntity item = new ItemEntity(level, this.getX(), this.getY() + 0.4, this.getZ(), stack);
        Vec3 dir = player.position().subtract(this.position());
        dir = new Vec3(dir.x, 0, dir.z).normalize().scale(0.2);
        item.setDeltaMovement(dir.x, 0.2, dir.z);
        item.setPickUpDelay(15);
        level.addFreshEntity(item);
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
        level.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 1.0, this.getZ(), 6, 0.4, 0.3, 0.4, 0.0);
        level.playSound(null, this.blockPosition(), SoundEvents.ALLAY_ITEM_GIVEN, SoundSource.NEUTRAL, 1.0F, 1.3F);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!this.isTame()) {
            if (!stack.is(Items.GOLDEN_CARROT)) return InteractionResult.PASS;
            if (this.level().isClientSide) return InteractionResult.CONSUME;
            int lvl = Innocence.getLevel(player);
            if (lvl < TAME_MIN_LEVEL) {
                if (player instanceof ServerPlayer sp) {
                    sp.displayClientMessage(Component.translatable("message.corazondemelon.mao_distrust"), true);
                }
                return InteractionResult.SUCCESS;
            }
            if (!player.getAbilities().instabuild) stack.shrink(1);
            if (this.random.nextInt(lvl >= 9 ? 2 : 3) == 0) {
                this.tame(player);
                this.setPersistenceRequired();
                this.navigation.stop();
                this.setTarget(null);
                this.setOrderedToSit(false);
                this.level().broadcastEntityEvent(this, (byte) 7);
                if (player instanceof ServerPlayer sp) {
                    sp.displayClientMessage(Component.translatable("message.corazondemelon.mao_tamed"), true);
                    Innocence.addXp(sp, 2.0F);
                    MaoRoster.onTamed(this, sp);
                }
            } else {
                this.level().broadcastEntityEvent(this, (byte) 6);
            }
            return InteractionResult.SUCCESS;
        }

        if (this.isOwnedBy(player)) {
            if (stack.is(Items.GOLDEN_CARROT) && this.getHealth() < this.getMaxHealth()) {
                if (!this.level().isClientSide) {
                    this.heal(8.0F);
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    this.level().broadcastEntityEvent(this, (byte) 7);
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
            if (!this.level().isClientSide) {
                if (this.representative) {
                    if (player instanceof ServerPlayer sp) {
                        sp.displayClientMessage(Component.translatable("message.corazondemelon.mao_rep_always"), true);
                    }
                    return InteractionResult.sidedSuccess(false);
                }
                boolean sit = !this.isOrderedToSit();
                if (sit) this.returnToFollow();
                this.setOrderedToSit(sit);
                this.setInSittingPose(sit);
                this.navigation.stop();
                this.setTarget(null);
                if (player instanceof ServerPlayer sp) {
                    sp.displayClientMessage(Component.translatable(sit
                            ? "message.corazondemelon.mao_sit" : "message.corazondemelon.mao_follow"), true);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    /** Un Mao domesticado es inmortal: ignora todo daño (salvo /kill de un admin). Si cae al vacío, vuelve con su dueño. */
    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (this.isTame() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true;
        return super.isInvulnerableTo(source);
    }

    @Override
    public boolean fireImmune() {
        return this.isTame() || super.fireImmune();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isTame() && source.is(DamageTypes.FELL_OUT_OF_WORLD)) {
            if (!this.level().isClientSide) this.rescue();
            return false;
        }
        if (this.isInvulnerableTo(source)) return false;
        if (!this.level().isClientSide) {
            this.setOrderedToSit(false);
            this.setInSittingPose(false);
        }
        return super.hurt(source, amount);
    }

    // ------------------------------------------------------------------ misc

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false;
    }

    @Override
    public boolean canMate(Animal other) {
        return false;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) {
        return null;
    }

    @Override
    public int getMaxSpawnClusterSize() {
        return 2;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ALLAY_AMBIENT_WITHOUT_ITEM;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ALLAY_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ALLAY_DEATH;
    }
}
