package com.corazondemelon.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * Inventario INFINITO de un Mao: no tiene huecos, solo cuenta cuántos objetos de cada tipo lleva
 * (con sus etiquetas NBT). Se guarda dentro del propio Mao.
 */
public final class MaoInventory {
    public static final class Entry {
        public final ItemStack proto;   // un solo objeto de ese tipo
        public long count;

        Entry(ItemStack proto, long count) {
            this.proto = proto;
            this.count = count;
        }
    }

    private final LinkedHashMap<String, Entry> items = new LinkedHashMap<>();

    private static String key(ItemStack s) {
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
        CompoundTag tag = s.getTag();
        return id + (tag == null ? "" : tag.toString());
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public Collection<Entry> entries() {
        return items.values();
    }

    public long total() {
        long n = 0;
        for (Entry e : items.values()) n += e.count;
        return n;
    }

    public void add(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return;
        String k = key(stack);
        Entry e = items.get(k);
        if (e == null) {
            ItemStack proto = stack.copy();
            proto.setCount(1);
            items.put(k, new Entry(proto, stack.getCount()));
        } else {
            e.count += stack.getCount();
        }
    }

    public long count(Predicate<ItemStack> test) {
        long n = 0;
        for (Entry e : items.values()) if (test.test(e.proto)) n += e.count;
        return n;
    }

    /** Saca hasta {@code max} objetos que cumplan la condición. Devuelve los stacks sacados (ya divididos por tamaño máximo). */
    public List<ItemStack> take(Predicate<ItemStack> test, long max) {
        List<ItemStack> out = new ArrayList<>();
        long left = max;
        Iterator<Map.Entry<String, Entry>> it = items.entrySet().iterator();
        while (it.hasNext() && left > 0) {
            Entry e = it.next().getValue();
            if (!test.test(e.proto)) continue;
            long n = Math.min(left, e.count);
            e.count -= n;
            left -= n;
            long rest = n;
            int stackMax = Math.max(1, e.proto.getMaxStackSize());
            while (rest > 0) {
                int c = (int) Math.min(stackMax, rest);
                ItemStack s = e.proto.copy();
                s.setCount(c);
                out.add(s);
                rest -= c;
            }
            if (e.count <= 0) it.remove();
        }
        return out;
    }

    /** Saca exactamente un objeto que cumpla la condición, o null si no hay. */
    public ItemStack takeOne(Predicate<ItemStack> test) {
        List<ItemStack> l = take(test, 1);
        return l.isEmpty() ? null : l.get(0);
    }

    public ListTag save() {
        ListTag list = new ListTag();
        for (Entry e : items.values()) {
            CompoundTag t = new CompoundTag();
            t.put("i", e.proto.save(new CompoundTag()));
            t.putLong("n", e.count);
            list.add(t);
        }
        return list;
    }

    public void load(ListTag list) {
        items.clear();
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            ItemStack proto = ItemStack.of(t.getCompound("i"));
            long n = t.getLong("n");
            if (proto.isEmpty() || n <= 0) continue;
            proto.setCount(1);
            items.put(key(proto), new Entry(proto, n));
        }
    }

    public static final int TAG_COMPOUND = Tag.TAG_COMPOUND;
}
