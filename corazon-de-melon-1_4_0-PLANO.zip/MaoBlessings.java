package com.corazondemelon.event;

import com.corazondemelon.CorazonDeMelon;
import com.corazondemelon.MelonConfig;
import com.corazondemelon.ai.MaoRoster;
import com.corazondemelon.entity.MaoEntity;
import com.corazondemelon.innocence.Innocence;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Lo que hacen los Maos por ti según tu Inocencia (corazones extra, regeneración, inmunidad a desventajas, revivir)
 * y el teletransporte de los Maos que te siguen a cualquier distancia.
 */
@Mod.EventBusSubscriber(modid = CorazonDeMelon.MOD_ID)
public final class MaoBlessings {
    /** Mantiene cargado el trozo de mundo donde está un Mao seguidor, para poder llevarlo contigo si te teletransportas lejos. */
    public static final TicketType<ChunkPos> MAO_TICKET =
            TicketType.create("corazondemelon_mao", Comparator.comparingLong(ChunkPos::toLong), 200);

    private static final UUID HEALTH_MOD = UUID.fromString("5b3f1a6e-4d1c-4f0a-9c5e-7d2a3b8e0c11");
    private static final String REVIVE_KEY = "corazondemelon_revive_next";

    private MaoBlessings() {}

    /** Vida extra (en puntos; 2 = un corazón) según el nivel de Inocencia. */
    public static int extraHealth(int level) {
        return switch (level) {
            case 6 -> 2;
            case 7 -> 4;
            case 8 -> 6;
            case 9 -> 8;
            case 10 -> 10;
            default -> 0;
        };
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) return;
        if (!(event.player instanceof ServerPlayer sp)) return;
        if (sp.tickCount % 10 != 0) return;
        List<MaoEntity> maos = MaoRoster.owned(sp, sp.tickCount % 200 == 0);
        if (maos.isEmpty()) {
            setExtraHealth(sp, 0);
            return;
        }
        followers(sp, maos);
        if (sp.tickCount % 20 == 0) blessings(sp, maos);
    }

    // ------------------------------------------------------------------ teletransporte de los seguidores

    private static void followers(ServerPlayer sp, List<MaoEntity> maos) {
        for (MaoEntity m : maos) {
            if (!m.isFollowing()) continue;
            boolean sameLevel = m.level() == sp.level();
            if (sameLevel && m.distanceToSqr(sp) < 24.0D * 24.0D) {
                // mientras esté cerca de ti, su trozo de mundo no se descarga aunque te teletransportes
                ChunkPos cp = m.chunkPosition();
                ((ServerLevel) m.level()).getChunkSource().addRegionTicket(MAO_TICKET, cp, 2, cp);
                continue;
            }
            if (!MelonConfig.FOLLOW_TELEPORT.get()) continue;
            if (!sp.level().hasChunkAt(sp.blockPosition())) continue;      // espera a que cargue tu zona
            ServerLevel from = (ServerLevel) m.level();
            from.sendParticles(ParticleTypes.PORTAL, m.getX(), m.getY() + 0.5, m.getZ(), 12, 0.3, 0.4, 0.3, 0.1);
            MaoEntity moved = m.warpTo(sp.serverLevel(), sp.getX() + 1.2D, sp.getY() + 1.0D, sp.getZ());
            if (moved != null && moved.level() instanceof ServerLevel to) {
                to.sendParticles(ParticleTypes.PORTAL, moved.getX(), moved.getY() + 0.5, moved.getZ(), 12, 0.3, 0.4, 0.3, 0.1);
            }
        }
    }

    // ------------------------------------------------------------------ bendiciones por nivel

    private static void setExtraHealth(ServerPlayer sp, int extra) {
        AttributeInstance maxHp = sp.getAttribute(Attributes.MAX_HEALTH);
        if (maxHp == null) return;
        AttributeModifier cur = maxHp.getModifier(HEALTH_MOD);
        double prev = cur == null ? 0.0D : cur.getAmount();
        if (prev == extra) return;
        if (cur != null) maxHp.removeModifier(HEALTH_MOD);
        if (extra > 0) {
            maxHp.addTransientModifier(new AttributeModifier(HEALTH_MOD, "corazondemelon_mao_hearts", extra, AttributeModifier.Operation.ADDITION));
            if (extra > prev) sp.heal((float) (extra - prev));
        }
        if (sp.getHealth() > sp.getMaxHealth()) sp.setHealth(sp.getMaxHealth());
    }

    private static void blessings(ServerPlayer sp, List<MaoEntity> maos) {
        boolean near = false;
        for (MaoEntity m : maos) {
            if (m.level() == sp.level() && m.distanceToSqr(sp) < 48.0D * 48.0D) {
                near = true;
                break;
            }
        }
        boolean on = near && MelonConfig.LEVEL_POWERS.get();
        int lvl = Innocence.getLevel(sp);
        setExtraHealth(sp, on ? extraHealth(lvl) : 0);
        if (!on) return;

        if (lvl >= 7 && sp.getHealth() < sp.getMaxHealth()) {
            sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, lvl >= 9 ? 1 : 0, true, false, false));
        }
        if (lvl >= 9) {
            for (MobEffectInstance inst : new ArrayList<>(sp.getActiveEffects())) {
                if (inst.getEffect().getCategory() == MobEffectCategory.HARMFUL && inst.getEffect() != MobEffects.BAD_OMEN) {
                    sp.removeEffect(inst.getEffect());
                }
            }
        } else if (lvl >= 8) {
            sp.removeEffect(MobEffects.POISON);
            sp.removeEffect(MobEffects.WITHER);
            sp.removeEffect(MobEffects.HUNGER);
            sp.removeEffect(MobEffects.CONFUSION);
        }
    }

    // ------------------------------------------------------------------ revivir (nivel 10)

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;
        if (!MelonConfig.LEVEL_POWERS.get() || Innocence.getLevel(sp) < Innocence.MAX_LEVEL) return;
        if (event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;     // /kill y el vacío no se pueden revivir
        long now = sp.level().getGameTime();
        if (now < sp.getPersistentData().getLong(REVIVE_KEY)) return;

        boolean maoNear = false;
        for (MaoEntity m : MaoRoster.owned(sp, false)) {
            if (m.isAlive() && m.level() == sp.level() && m.distanceToSqr(sp) < 64.0D * 64.0D) {
                maoNear = true;
                break;
            }
        }
        if (!maoNear) return;

        event.setCanceled(true);
        sp.setHealth(Math.max(4.0F, sp.getMaxHealth() * 0.5F));
        sp.removeAllEffects();
        sp.clearFire();
        sp.fallDistance = 0.0F;
        sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        sp.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1));
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 2));
        sp.getPersistentData().putLong(REVIVE_KEY, now + MelonConfig.REVIVE_COOLDOWN_MIN.get() * 1200L);
        ServerLevel level = sp.serverLevel();
        level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, sp.getX(), sp.getY() + 1.0, sp.getZ(), 40, 0.5, 0.8, 0.5, 0.3);
        level.playSound(null, sp.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1.0F, 1.0F);
        sp.sendSystemMessage(Component.literal("¡Tu Mao te ha revivido con su luz! Podrá volver a hacerlo en "
                + MelonConfig.REVIVE_COOLDOWN_MIN.get() + " minutos."));
    }
}
