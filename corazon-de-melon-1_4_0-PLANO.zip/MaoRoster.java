package com.corazondemelon.ai;

import com.corazondemelon.entity.MaoEntity;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * La «lista de Maos» de un jugador: el primero que domestica es el Mao REPRESENTANTE (se llama siempre «Mao»,
 * te sigue a todas partes y no se puede renombrar); los demás se pueden renombrar para no confundirlos.
 * Se guarda en los datos del jugador (la lista de UUID) y en cada Mao (su nombre).
 */
public final class MaoRoster {
    public static final String KEY_LIST = "corazondemelon_maos";
    public static final String KEY_REP = "corazondemelon_mao_rep";

    /** Mensaje dirigido a uno o a todos los Maos. */
    public record Target(List<MaoEntity> maos, String text, boolean all) {}

    private static final Pattern ALL = Pattern.compile("^@?(?:maos|todos(?:\\s+los\\s+maos)?)\\s*[\\s,:;!¡]+(.+)$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern GENERIC = Pattern.compile("^@?mao[\\s,:;!¡]+(.+)$", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private MaoRoster() {}

    private static ListTag list(ServerPlayer p) {
        return p.getPersistentData().getList(KEY_LIST, Tag.TAG_STRING);
    }

    public static String nameOf(MaoEntity m) {
        return m.getCustomName() != null ? m.getCustomName().getString() : "Mao";
    }

    /** Apunta un Mao recién domesticado (o descubierto) en la lista del jugador. */
    public static void register(ServerPlayer p, MaoEntity m) {
        ListTag l = list(p);
        String id = m.getUUID().toString();
        boolean known = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.getString(i).equals(id)) {
                known = true;
                break;
            }
        }
        if (!known) {
            l.add(StringTag.valueOf(id));
            p.getPersistentData().put(KEY_LIST, l);
        }
        String rep = p.getPersistentData().getString(KEY_REP);
        if (rep.isEmpty()) {
            rep = id;
            p.getPersistentData().putString(KEY_REP, id);
        }
        if (rep.equals(id)) {
            m.makeRepresentative();
        } else {
            if (m.getCustomName() == null) m.setCustomName(Component.literal("Mao " + Math.max(2, l.size())));
            m.setCustomNameVisible(true);
        }
    }

    public static void forget(ServerPlayer p, MaoEntity m) {
        ListTag l = list(p);
        String id = m.getUUID().toString();
        ListTag out = new ListTag();
        for (int i = 0; i < l.size(); i++) if (!l.getString(i).equals(id)) out.add(StringTag.valueOf(l.getString(i)));
        p.getPersistentData().put(KEY_LIST, out);
        if (id.equals(p.getPersistentData().getString(KEY_REP))) p.getPersistentData().remove(KEY_REP);
    }

    /** Todos los Maos del jugador que estén cargados ahora mismo (en cualquier dimensión). */
    public static List<MaoEntity> owned(ServerPlayer p, boolean scanNearby) {
        LinkedHashMap<UUID, MaoEntity> out = new LinkedHashMap<>();
        ListTag l = list(p);
        for (int i = 0; i < l.size(); i++) {
            UUID id;
            try {
                id = UUID.fromString(l.getString(i));
            } catch (IllegalArgumentException e) {
                continue;
            }
            for (ServerLevel lv : p.server.getAllLevels()) {
                Entity e = lv.getEntity(id);
                if (e instanceof MaoEntity m && m.isAlive() && m.isOwnedByUuid(p)) {
                    out.put(id, m);
                    break;
                }
            }
        }
        if (scanNearby) {
            for (MaoEntity m : p.level().getEntitiesOfClass(MaoEntity.class, p.getBoundingBox().inflate(64),
                    x -> x.isAlive() && x.isOwnedByUuid(p))) {
                if (!out.containsKey(m.getUUID())) {
                    register(p, m);
                    out.put(m.getUUID(), m);
                }
            }
            if (out.isEmpty() && l.isEmpty()) {
                MaoEntity legacy = MaoEntity.scanOwned(p);
                if (legacy != null) {
                    register(p, legacy);
                    out.put(legacy.getUUID(), legacy);
                }
            }
        }
        return new ArrayList<>(out.values());
    }

    public static List<MaoEntity> owned(ServerPlayer p) {
        return owned(p, true);
    }

    public static List<MaoEntity> followers(ServerPlayer p) {
        List<MaoEntity> out = new ArrayList<>();
        for (MaoEntity m : owned(p, false)) if (m.isFollowing()) out.add(m);
        return out;
    }

    /** El Mao representante si está cargado; si no, el más cercano. */
    public static MaoEntity primary(ServerPlayer p) {
        List<MaoEntity> all = owned(p);
        if (all.isEmpty()) return null;
        for (MaoEntity m : all) if (m.isRepresentative()) return m;
        return all.stream().min(Comparator.comparingDouble(m -> m.level() == p.level() ? m.distanceToSqr(p) : Double.MAX_VALUE)).orElse(null);
    }

    /** Busca un Mao del jugador por su nombre (ignora mayúsculas y tildes). */
    public static MaoEntity byName(ServerPlayer p, String name) {
        String key = MaoPlaces.norm(name);
        if (key.isEmpty()) return null;
        MaoEntity partial = null;
        for (MaoEntity m : owned(p)) {
            String n = MaoPlaces.norm(nameOf(m));
            if (n.equals(key)) return m;
            if (partial == null && (n.contains(key) || key.contains(n)) && !n.equals("mao")) partial = m;
        }
        return partial;
    }

    /** Si el mensaje empieza por el nombre de alguno de tus Maos («Mao 2, ven», «Luna: quédate», «Todos, venid»). */
    public static Target resolve(ServerPlayer p, String raw) {
        if (raw == null || raw.isBlank()) return null;
        String text = raw.trim();
        List<MaoEntity> maos = owned(p);
        if (maos.isEmpty()) return null;

        Matcher all = ALL.matcher(text);
        if (all.matches()) return new Target(maos, all.group(1).trim(), true);

        List<MaoEntity> byLen = new ArrayList<>(maos);
        byLen.sort((a, b) -> nameOf(b).length() - nameOf(a).length());
        for (MaoEntity m : byLen) {
            String name = nameOf(m);
            String q = Pattern.quote(name);
            Pattern pt;
            if (MaoPlaces.norm(name).startsWith("mao")) {
                pt = Pattern.compile("^@?" + q + "(?:\\s*[,:;!¡]+\\s*|\\s+)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            } else {
                pt = Pattern.compile("^(?:@" + q + "(?:\\s*[,:;!¡]+\\s*|\\s+)|" + q + "\\s*[,:;]+\\s*)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            }
            Matcher mt = pt.matcher(text);
            if (mt.find()) {
                String rest = text.substring(mt.end()).trim();
                if (!rest.isEmpty()) return new Target(List.of(m), rest, false);
            }
        }
        Matcher g = GENERIC.matcher(text);
        if (g.matches()) {
            MaoEntity near = primary(p);
            if (near != null) return new Target(List.of(near), g.group(1).trim(), false);
        }
        return null;
    }

    /** Para /mao <mensaje>: igual que resolve, pero si no empieza por un nombre se lo dices al representante. */
    public static Target resolveOrDefault(ServerPlayer p, String raw) {
        Target t = resolve(p, raw);
        if (t != null) return t;
        MaoEntity m = primary(p);
        return m == null ? null : new Target(List.of(m), raw.trim(), false);
    }

    /** Se llama al domesticar un Mao. */
    public static void onTamed(MaoEntity mao, ServerPlayer player) {
        register(player, mao);
        if (!mao.isRepresentative()) {
            player.displayClientMessage(Component.literal("Este es " + nameOf(mao)
                    + ". Puedes cambiarle el nombre: «" + nameOf(mao) + ", llámate Luna». El primer Mao es tu representante y siempre va contigo."), false);
        } else {
            player.displayClientMessage(Component.literal("Este es tu Mao representante: te seguirá a todas partes, siempre."), false);
        }
    }
}
